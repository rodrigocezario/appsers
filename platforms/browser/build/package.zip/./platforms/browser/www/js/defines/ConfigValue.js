angular.module("appsers").constant("config", {
    baseUrl: "http://localhost"
});